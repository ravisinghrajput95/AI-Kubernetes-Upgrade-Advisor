# Kubernetes Upgrade Assessment — 1.26 → 1.40

**Verdict: ⛔ BLOCKED**  
Readiness **6/100** (capped at 70: target version is beyond the reviewed static-table horizon — API removals and compatibility for newer minors are unexamined) · Confidence **94/100**

`assess-20260818-033656-b02c92` · 2026-08-18 03:36 UTC · cluster: **eks** · hops: 1.26→1.27 → 1.27→1.28 → 1.28→1.29 → 1.29→1.30 → 1.30→1.31 → 1.31→1.32 → 1.32→1.33 → 1.33→1.34 → 1.34→1.35 → 1.35→1.36 → 1.36→1.37 → 1.37→1.38 → 1.38→1.39 → 1.39→1.40

## Executive Summary

[dry-run] Deterministic assessment only — no LLM narrative was generated. Verdict blocked with readiness 6/100 from 13 findings.

## Cluster Profile

- **Distribution:** eks (apiserver gitVersion 'v1.26.12-eks-1234' has EKS suffix)
- **Current version:** v1.26.12-eks-1234
- **Nodes:** 3 · **Workloads:** 3 deploy / 0 sts / 0 ds / 0 cron
- **Upgrade mechanism:** Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
- **Provider-managed:** etcd, kube-apiserver, kube-controller-manager, kube-scheduler, coredns (addon), kube-proxy (addon), vpc-cni (addon)

| Component | Version | Evidence |
|---|---|---|
| AWS VPC CNI | 1.13.0 | image |
| Karpenter | 0.31.0 | image |
| ingress-nginx | 1.8.1 | image |
| cert-manager | 1.11.0 | helm |

## Findings (13)

### 🔴 cgroup v1 disabled by default — kubelet fails to start on cgroup v1 nodes **[BLOCKING]**

`critical` · `kep-impact` · origin: `deterministic` · effective in **1.35**

From 1.35 the kubelet's failCgroupV1 setting defaults to true: this is a hard failure, not a warning. A kubelet on a node still running the cgroup v1 hierarchy refuses to initialise, so the node never becomes Ready after the upgrade. The failCgroupV1=false escape hatch exists but defers the inevitable and blocks cgroup-v2-only features.

**Remediation:** Confirm every node OS image boots with the cgroup v2 unified hierarchy (stat -fc %T /sys/fs/cgroup == cgroup2fs) before upgrading past 1.34; rebuild/replace node pools still on cgroup v1.

<details><summary>Evidence</summary>

- _static-table_: cgroup v1 disabled by default — kubelet fails to start on cgroup v1 nodes — effective in Kubernetes 1.35 (KEP-5573)

</details>

### 🟠 containerd 1.x support removed — nodes need containerd 2.x

`high` · `kep-impact` · origin: `deterministic` · effective in **1.36**

1.35 is the last release supporting containerd 1.x; from 1.36 the kubelet requires containerd 2.x (or another CRI 2.x runtime). Nodes still on containerd 1.x must be upgraded, and containerd 2.0 drops the deprecated registry.configs / registry.auths config structures, so runtime config may need rewriting.

**Remediation:** Upgrade node containerd to 2.x before crossing 1.36 and migrate any registry.configs/registry.auths settings to the 2.0 config format.

<details><summary>Evidence</summary>

- _static-table_: containerd 1.x support removed — nodes need containerd 2.x — effective in Kubernetes 1.36 (KEP-4033)

</details>

### 🟠 FlowSchema, PriorityLevelConfiguration (flowcontrol.apiserver.k8s.io/v1beta2) removed in 1.29

`high` · `removed-api` · origin: `deterministic` · effective in **1.29**

The cluster still serves flowcontrol.apiserver.k8s.io/v1beta2, which is removed in Kubernetes 1.29 (inside this upgrade path). Any manifest, Helm chart, controller, or stored object using this version fails after the hop to 1.29.

**Remediation:** Migrate to flowcontrol.apiserver.k8s.io/v1. Audit usage before upgrading: kubectl get flowschema.flowcontrol.apiserver.k8s.io -A; kubectl get prioritylevelconfiguration.flowcontrol.apiserver.k8s.io -A. Tools like 'pluto detect-all-in-cluster' or 'kubent' find manifests pinned to removed versions.

<details><summary>Evidence</summary>

- _cluster-data_: API group version 'flowcontrol.apiserver.k8s.io/v1beta2' is served by this cluster (kubectl api-versions) and is removed in Kubernetes 1.29.
- _static-table_: Deprecated 1.26, removed 1.29. Replacement: flowcontrol.apiserver.k8s.io/v1.

</details>

### 🟠 Target 1.40 is beyond the reviewed knowledge horizon (1.36)

`high` · `upgrade-path` · origin: `deterministic`

The static API-lifecycle and compatibility tables in this build were last reviewed against Kubernetes 1.36 (on 2026-08-17). API removals and component support for 1.37, 1.38, 1.39, 1.40 are NOT covered — an empty findings list for those minors means unexamined, not safe. Readiness is capped accordingly.

**Remediation:** Upgrade k8s-upgrade-advisor to a build whose tables cover the target minor, and cross-check the official deprecation guide and CHANGELOG for versions beyond the horizon.

<details><summary>Evidence</summary>

- _static-table_: Table coverage ends at 1.36; target is 1.40.

</details>

### 🟠 kubelet 1.26 will violate skew policy at control plane 1.30 **[BLOCKING]**

`high` · `version-skew` · origin: `deterministic`

3 node(s) run kubelet 1.26 (ip-10-0-0-1.ec2.internal, ip-10-0-1-1.ec2.internal, ip-10-0-2-1.ec2.internal). The skew policy allows kubelets at most 3 minors behind the apiserver, so these nodes will violate the policy when the control plane reaches 1.30.

**Affected:** ip-10-0-0-1.ec2.internal, ip-10-0-1-1.ec2.internal, ip-10-0-2-1.ec2.internal

**Remediation:** Upgrade these node pools to within 3 minors before the control plane hop to 1.30.

<details><summary>Evidence</summary>

- _cluster-data_: kubelet versions from node inventory: 3 node(s) at 1.26.
- _static-table_: Skew policy: kubelet may trail apiserver by 3 minors at control plane 1.30.

</details>

### 🟡 exec/attach/port-forward now require the 'create' verb

`medium` · `breaking-change` · origin: `deterministic` · effective in **1.35**

From 1.35 WebSocket streaming requests (kubectl exec, attach, port-forward) are authorised against the 'create' verb on the pod subresource rather than 'get'. RBAC roles that granted only 'get' on pods/exec, pods/attach, or pods/portforward stop permitting those actions after the upgrade.

**Remediation:** Audit Roles/ClusterRoles granting pods/exec, pods/attach, or pods/portforward and ensure they include the 'create' verb.

<details><summary>Evidence</summary>

- _static-table_: exec/attach/port-forward now require the 'create' verb — effective in Kubernetes 1.35

</details>

### 🟡 14-hop upgrade path: control plane must move one minor at a time

`medium` · `upgrade-path` · origin: `deterministic`

Kubernetes does not support skipping minors for the control plane. 1.26 → 1.40 requires sequential hops: 1.27 → 1.28 → 1.29 → 1.30 → 1.31 → 1.32 → 1.33 → 1.34 → 1.35 → 1.36 → 1.37 → 1.38 → 1.39 → 1.40. Each hop needs its own validation gate; API removals apply per-hop, not only at the final version.

**Remediation:** Plan and validate each hop independently; do not batch hops in one window.

<details><summary>Evidence</summary>

- _static-table_: Kubernetes version skew policy: kube-apiserver upgrades are supported only from the previous minor.

</details>

### 🔵 cgroup v1 support in maintenance mode

`low` · `breaking-change` · origin: `deterministic` · effective in **1.31**

kubelet cgroup v1 support is feature-frozen from 1.31; distros and node images should be on cgroup v2.

**Remediation:** Verify node OS images use cgroup v2 (systemd unified hierarchy).

<details><summary>Evidence</summary>

- _static-table_: cgroup v1 support in maintenance mode — effective in Kubernetes 1.31

</details>

### 🔵 Service .spec.externalIPs deprecated

`low` · `breaking-change` · origin: `deterministic` · effective in **1.36**

From 1.36 Service .spec.externalIPs is deprecated: the apiserver warns on its use. The field is a long-standing man-in-the-middle risk (CVE-2020-8554) and is slated for removal in a future release.

**Remediation:** Move Services off .spec.externalIPs to LoadBalancer/NodePort or an ingress controller; where it must stay, gate it with the DenyServiceExternalIPs admission controller.

<details><summary>Evidence</summary>

- _static-table_: Service .spec.externalIPs deprecated — effective in Kubernetes 1.36

</details>

### 🔵 kube-proxy IPVS mode deprecated

`low` · `kep-impact` · origin: `deterministic` · effective in **1.35**

From 1.35 the kube-proxy IPVS mode is formally deprecated, with nftables mode positioned as the long-term replacement. IPVS keeps working for now but removal is targeted for a later release (~1.38), so clusters pinning --proxy-mode=ipvs should plan a migration.

**Remediation:** Plan migration of kube-proxy from IPVS to the nftables (or iptables) mode ahead of its removal; validate Service/NetworkPolicy behaviour on nftables.

<details><summary>Evidence</summary>

- _static-table_: kube-proxy IPVS mode deprecated — effective in Kubernetes 1.35 (KEP-5495)

</details>

### ⚪ Endpoints API deprecated in favour of EndpointSlices

`info` · `breaking-change` · origin: `deterministic` · effective in **1.33**

From 1.33 the core v1 Endpoints API is formally deprecated: the apiserver emits deprecation warnings when clients read or write Endpoints. The type is not scheduled for removal, but scripts, controllers, and integrations reading Endpoints directly should move to EndpointSlices (stable since 1.21, and the only API with dual-stack and topology data).

**Remediation:** Migrate controllers/scripts that consume Endpoints to the discovery.k8s.io/v1 EndpointSlices API.

<details><summary>Evidence</summary>

- _static-table_: Endpoints API deprecated in favour of EndpointSlices — effective in Kubernetes 1.33

</details>

### ⚪ Unused auto-generated ServiceAccount tokens are invalidated

`info` · `kep-impact` · origin: `deterministic` · effective in **1.29**

From 1.29 (LegacyServiceAccountTokenCleanUp beta, on by default) auto-generated legacy token Secrets unused for a year are labelled invalid and later deleted. Long-forgotten external credentials stop working some time after the upgrade, not during it.

**Remediation:** Audit kubernetes.io/service-account-token Secrets and migrate consumers to TokenRequest before relying on them post-upgrade.

<details><summary>Evidence</summary>

- _static-table_: Unused auto-generated ServiceAccount tokens are invalidated — effective in Kubernetes 1.29 (KEP-2799)

</details>

### ⚪ kubelet version skew widened to n-3

`info` · `kep-impact` · origin: `deterministic` · effective in **1.28**

From 1.28 the control plane supports kubelets up to three minors older, enabling fewer node pool upgrade waves on long paths.

<details><summary>Evidence</summary>

- _static-table_: kubelet version skew widened to n-3 — effective in Kubernetes 1.28 (KEP-3935)

</details>

## Compatibility Matrix

Target: Kubernetes 1.40

| Component | Installed | Status | Min required | Notes |
|---|---|---|---|---|
| AWS VPC CNI | 1.13.0 | unknown | — | No static support matrix tracked; verify against upstream docs. |
| Karpenter | 0.31.0 | unknown | — | No support-matrix data for Kubernetes 1.40; verify upstream. |
| ingress-nginx | 1.8.1 | unknown | — | No support-matrix data for Kubernetes 1.40; verify upstream. |
| cert-manager | 1.11.0 | unknown | — | No support-matrix data for Kubernetes 1.40; verify upstream. |

## Upgrade Plan

**Strategy:** sequential in-place upgrade, one minor per maintenance window

### Preparation

1. **Snapshot cluster state and back up** _(~15 min, disruption: none)_
   etcd snapshot (self-managed) or velero backup; export current manifests for diffing.
   - `velero backup create pre-upgrade-$(date +%Y%m%d)`
   - `kubectl get all -A -o yaml > pre-upgrade-state.yaml`

2. **Remediate removed-API usage flagged in findings** _(~60 min, disruption: none)_
   Every finding in the removed-api category must be resolved before the first hop.
   - `pluto detect-all-in-cluster`
   - `kubent`

3. **Upgrade webhook-backed operators to target-compatible versions** _(~30 min, disruption: none)_
   cert-manager, policy engines, and other admission webhooks must support the target version *before* the control plane moves — a failing webhook can block all admissions cluster-wide.

4. **Verify PodDisruptionBudgets allow node drains** _(~15 min, disruption: none)_
   PDBs with maxUnavailable: 0 or single-replica workloads without PDBs will stall or take downtime during node rotation.
   - `kubectl get pdb -A`

### Control Plane

5. **Upgrade control plane to 1.27** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.27 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.27`

### Addons

6. **Upgrade cluster addons for 1.27** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.27; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=0.29, cert-manager → >=1.12, ingress-nginx → >=1.8.0.

### Node Pools

7. **Roll node pools to 1.27** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.27`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

8. **Validate hop to 1.27 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

9. **Upgrade control plane to 1.28** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.28 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.28`

### Addons

10. **Upgrade cluster addons for 1.28** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.28; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=0.31, cert-manager → >=1.13, ingress-nginx → >=1.9.0.

### Node Pools

11. **Roll node pools to 1.28** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.28`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

12. **Validate hop to 1.28 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

13. **Upgrade control plane to 1.29** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.29 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.29`

### Addons

14. **Upgrade cluster addons for 1.29** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.29; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=0.34, cert-manager → >=1.14, ingress-nginx → >=1.10.0.

### Node Pools

15. **Roll node pools to 1.29** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.29`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

16. **Validate hop to 1.29 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

17. **Upgrade control plane to 1.30** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.30 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.30`

### Addons

18. **Upgrade cluster addons for 1.30** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.30; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=0.37, cert-manager → >=1.15, ingress-nginx → >=1.10.1.

### Node Pools

19. **Roll node pools to 1.30** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.30`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

20. **Validate hop to 1.30 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

21. **Upgrade control plane to 1.31** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.31 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.31`

### Addons

22. **Upgrade cluster addons for 1.31** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.31; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.0, cert-manager → >=1.16, ingress-nginx → >=1.11.2.

### Node Pools

23. **Roll node pools to 1.31** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.31`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

24. **Validate hop to 1.31 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

25. **Upgrade control plane to 1.32** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.32 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.32`

### Addons

26. **Upgrade cluster addons for 1.32** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.32; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.2, cert-manager → >=1.16, ingress-nginx → >=1.12.0.

### Node Pools

27. **Roll node pools to 1.32** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.32`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

28. **Validate hop to 1.32 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

29. **Upgrade control plane to 1.33** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.33 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.33`

### Addons

30. **Upgrade cluster addons for 1.33** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.33; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.4, cert-manager → >=1.17, ingress-nginx → >=1.12.1.

### Node Pools

31. **Roll node pools to 1.33** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.33`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

32. **Validate hop to 1.33 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

33. **Upgrade control plane to 1.34** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.34 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.34`

### Addons

34. **Upgrade cluster addons for 1.34** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.34; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.6, cert-manager → >=1.19, ingress-nginx → >=1.13.0.

### Node Pools

35. **Roll node pools to 1.34** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.34`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

36. **Validate hop to 1.34 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

37. **Upgrade control plane to 1.35** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.35 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.35`

### Addons

38. **Upgrade cluster addons for 1.35** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.35; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.9, cert-manager → >=1.20, ingress-nginx → >=1.15.0.

### Node Pools

39. **Roll node pools to 1.35** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.35`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

40. **Validate hop to 1.35 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

41. **Upgrade control plane to 1.36** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.36 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.36`

### Addons

42. **Upgrade cluster addons for 1.36** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.36; managed addons via provider APIs. Detected components required at this hop: Karpenter → >=1.13, cert-manager → >=1.21.

### Node Pools

43. **Roll node pools to 1.36** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.36`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

44. **Validate hop to 1.36 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

45. **Upgrade control plane to 1.37** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.37 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.37`

### Addons

46. **Upgrade cluster addons for 1.37** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.37; managed addons via provider APIs.

### Node Pools

47. **Roll node pools to 1.37** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.37`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

48. **Validate hop to 1.37 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

49. **Upgrade control plane to 1.38** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.38 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.38`

### Addons

50. **Upgrade cluster addons for 1.38** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.38; managed addons via provider APIs.

### Node Pools

51. **Roll node pools to 1.38** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.38`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

52. **Validate hop to 1.38 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

53. **Upgrade control plane to 1.39** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.39 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.39`

### Addons

54. **Upgrade cluster addons for 1.39** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.39; managed addons via provider APIs.

### Node Pools

55. **Roll node pools to 1.39** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.39`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

56. **Validate hop to 1.39 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Control Plane

57. **Upgrade control plane to 1.40** _(~10 min, disruption: none)_
   Distribution mechanism: Managed control plane via EKS API (eksctl/console/IaC); managed node groups or Karpenter node rotation
   - `eksctl upgrade cluster --name <cluster> --version 1.40 --approve`
   - `aws eks update-cluster-version --name <cluster> --kubernetes-version 1.40`

### Addons

58. **Upgrade cluster addons for 1.40** _(~20 min, disruption: none)_
   CoreDNS, kube-proxy, CNI, CSI drivers, metrics-server to versions matching 1.40; managed addons via provider APIs.

### Node Pools

59. **Roll node pools to 1.40** _(~24 min, disruption: rolling)_
   1 node pool(s) detected (workers-a). Upgrade one pool at a time; start with the least critical. Use surge settings to keep capacity during rotation.
   - `eksctl upgrade nodegroup --cluster <cluster> --name <ng> --kubernetes-version 1.40`
   - `# Karpenter nodes: drift replacement picks up the new AMI automatically`

### Validation

60. **Validate hop to 1.40 before proceeding** _(~15 min, disruption: none)_
   Gate the next hop on: all nodes Ready at the new version, no CrashLoopBackOffs, webhook and DNS health, workload smoke tests.
   - `kubectl get nodes`
   - `kubectl get pods -A | grep -v Running | grep -v Completed`

### Workloads

61. **Run application-level verification** _(~30 min, disruption: none)_
   Synthetic checks / golden transactions against critical services; compare error rates and latency to the pre-upgrade baseline.

## Rollback Plan

1. **Control plane rollback reality** — Managed control planes (EKS/GKE/AKS) cannot be downgraded once upgraded. Self-managed: kubeadm downgrade is unsupported territory once etcd schema migrates — restore from the etcd snapshot instead. Rollback planning must therefore be *forward-fix for the control plane, backward-roll for nodes*.
2. **Roll nodes back to previous version** — Recreate node pools pinned to the previous version/AMI and drain new-version nodes.
3. **Revert workload/addon changes** — Helm rollback for addons upgraded during the window; redeploy prior manifests via GitOps history.
   - `helm rollback <release> <revision>`

## Pre-Upgrade Checklist

- [ ] All removed-API findings remediated and verified with pluto/kubent
- [ ] Webhook operators (cert-manager, policy engines) at target-compatible versions
- [ ] etcd snapshot / velero backup completed and restore-tested
- [ ] PDBs reviewed; no maxUnavailable: 0 deadlocks
- [ ] Maintenance window and rollback decision criteria agreed
- [ ] Monitoring dashboards and alerts green before starting
- [ ] Cloud provider release notes for the target version reviewed

## Post-Upgrade Validation

- [ ] All nodes Ready at target kubelet version (kubectl get nodes)
- [ ] No pods in CrashLoopBackOff/ImagePullBackOff introduced by the upgrade
- [ ] Admission webhooks answering (create a dry-run object through each)
- [ ] DNS resolution healthy (CoreDNS metrics/log check)
- [ ] Ingress traffic serving; certificate issuance verified if cert-manager present
- [ ] Autoscaling verified (scale a canary deployment; node provisioning if Karpenter/CA)
- [ ] Application golden-path checks pass; error budgets not consumed
- [ ] Deprecation warnings in audit logs reviewed for the *next* upgrade

## Downtime & Disruption Estimate

- **Control plane:** None expected — managed control plane upgrades are non-disruptive to the API.
- **Workloads:** Zero expected for PDB-protected, multi-replica workloads; single-replica pods restart once per node rotation.
- **Estimated window:** ~1036 minutes
- _Assumption: 3 nodes, 3 workloads, 14 hop(s)_
- _Assumption: Surge capacity available for node rotation_
- _Assumption: 1 PodDisruptionBudget(s) present_

## Unknown Risks (honest gaps)

- No load/canary testing performed — runtime behaviour under production traffic during the upgrade is unverified.

## Sources

- **[DOC 1]** [cert-manager supported releases](https://cert-manager.io/docs/releases/)
- **[DOC 2]** [Kubernetes 1.33 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.33.md) (Kubernetes 1.33)
- **[DOC 3]** [AKS supported Kubernetes versions](https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions)
- **[DOC 4]** [AKS — Upgrade a cluster](https://learn.microsoft.com/en-us/azure/aks/upgrade-cluster)
- **[DOC 5]** [AKS — Upgrade a cluster § Scale the node pool to restore the original size](https://learn.microsoft.com/en-us/azure/aks/upgrade-cluster)
- **[DOC 6]** [AKS supported Kubernetes versions](https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions)
- **[DOC 7]** [AKS supported Kubernetes versions](https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions)
- **[DOC 8]** [GKE release notes](https://cloud.google.com/kubernetes-engine/docs/release-notes)
- **[DOC 9]** [Kubernetes 1.33 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.33.md) (Kubernetes 1.33)
- **[DOC 10]** [Kubernetes 1.33 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.33.md) (Kubernetes 1.33)
- **[DOC 11]** [Kubernetes 1.35 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.35.md) (Kubernetes 1.35)
- **[DOC 12]** [Kubernetes 1.34 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.34.md) (Kubernetes 1.34)
- **[DOC 13]** [GKE release notes](https://cloud.google.com/kubernetes-engine/docs/release-notes)
- **[DOC 14]** [AKS supported Kubernetes versions](https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions)
- **[DOC 15]** [GKE release notes](https://cloud.google.com/kubernetes-engine/docs/release-notes)
- **[DOC 16]** [Kubernetes Version Skew Policy](https://kubernetes.io/releases/version-skew-policy/)
- **[DOC 17]** [Kubernetes Version Skew Policy](https://kubernetes.io/releases/version-skew-policy/)
- **[DOC 18]** [Karpenter compatibility matrix](https://karpenter.sh/docs/upgrading/compatibility/)
- **[DOC 19]** [Amazon EKS Kubernetes versions](https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html)
- **[DOC 20]** [Kubernetes 1.36 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.36.md) (Kubernetes 1.36)
- **[DOC 21]** [Kubernetes 1.32 CHANGELOG](https://raw.githubusercontent.com/kubernetes/kubernetes/master/CHANGELOG/CHANGELOG-1.32.md) (Kubernetes 1.32)
- **[DOC 22]** [AKS supported Kubernetes versions](https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions)
- **[DOC 23]** [Karpenter compatibility matrix](https://karpenter.sh/docs/upgrading/compatibility/)
- **[DOC 24]** [GKE release notes](https://cloud.google.com/kubernetes-engine/docs/release-notes)

## Evidence Appendix

- kubectl commands: 15/15 succeeded (critical: 9/9)
- Component versions resolved: 4/4
- KB chunks retrieved: 24 from 12 documents
- LLM: none/none (dry run)

---
_Generated by k8s-upgrade-advisor. Deterministic findings are provable from cluster data and static lifecycle tables; LLM-origin content is labelled._