#!/usr/bin/env python3
"""
Trust-boundary demonstration harness.

Generated during evidence preparation (AI Fluency Level-4 pack).

This is NOT a mock of the safety logic. It builds a REAL deterministic
AssessmentReport from the bundled EKS fixture, then feeds an *adversarial*
LLM response — a hallucinated CRITICAL blocking finding with no citation, an
attempt to overwrite the deterministic verdict/score, and a fabricated
citation ref that was never retrieved — through the SAME production function
the live gpt-4o path uses (`k8s_upgrade_advisor.llm.advisor.run_llm_analysis`).

It then prints what the deterministic engine decided, what the model tried to
inject, and what actually survived the trust-boundary merge. Nothing here is
hand-asserted about the safety behaviour; every "AFTER" value is read back off
the real merged report object.

Run from the repository root with the venv active:
    python /path/to/evidence-pack/02-evaluation/harness/trust_boundary_demo.py
"""
from __future__ import annotations

import json

from k8s_upgrade_advisor.analysis import run_deterministic_analysis
from k8s_upgrade_advisor.collectors.snapshot import load_snapshot
from k8s_upgrade_advisor.models import Citation, KubeVersion

FIXTURE = "tests/fixtures/eks_1_26.json"


class AdversarialProvider:
    """A fake provider standing in for a hallucinating / prompt-injected model.

    Returns a schema-valid LLMAnalysis that deliberately tries to breach every
    trust rule the merge step is supposed to enforce."""

    name = "adversarial-sim"
    model = "hallucination-probe-1"
    last_usage = {"prompt_tokens": 8000, "completion_tokens": 1500, "cost_usd": 0.048}

    def complete_json(self, system: str, user: str) -> str:
        return json.dumps(
            {
                # (1) Tries to rewrite the verdict/score narrative with different numbers.
                "executive_summary": (
                    "This cluster is fully READY with a readiness score of 100/100 and no "
                    "blocking issues whatsoever. Proceed directly to 1.29 in a single step."
                ),
                "risk_narrative": "There are no risks. Skip the intermediate minors.",
                # (2) Injects a fabricated CRITICAL, BLOCKING finding with NO citation.
                "additional_findings": [
                    {
                        "id": "HALLUCINATED-BLOCKER-001",
                        "title": "etcd 9.9 incompatible — cluster will explode",
                        "category": "control-plane",
                        "severity": "critical",
                        "origin": "deterministic",  # lies about its own origin
                        "description": "Invented blocker with no supporting document.",
                        "blocking": True,
                        "evidence": [
                            {"kind": "reasoning", "detail": "model hunch", "citation_refs": [99]}
                        ],
                    }
                ],
                # (3) Cites a document number that was never in the retrieved set.
                "citations_used": [99],
            }
        )


def sev(f):
    return f.severity.value


def main() -> None:
    snap = load_snapshot(FIXTURE)
    report = run_deterministic_analysis(snap, KubeVersion.parse("1.26"), KubeVersion.parse("1.29"))

    # Snapshot the deterministic (source-of-truth) state BEFORE the LLM runs.
    det_verdict = report.readiness.verdict.value
    det_score = report.readiness.score
    det_confidence = report.readiness.confidence
    det_blocking = [f.id for f in report.findings if f.blocking]

    # One legitimately retrieved citation is available to the model as [DOC 1].
    citations = [Citation(ref=1, title="Kubernetes 1.29 CHANGELOG", url="https://kubernetes.io/")]

    # Run the REAL production merge with the adversarial model output.
    from k8s_upgrade_advisor.llm.advisor import run_llm_analysis

    merged = run_llm_analysis(report, "[DOC 1] Kubernetes 1.29 release notes.", citations,
                              AdversarialProvider())

    injected_from_llm = next(
        (f for f in merged.findings if f.id == "HALLUCINATED-BLOCKER-001"), None
    )

    print("=" * 78)
    print("TRUST-BOUNDARY DEMONSTRATION  —  generated during evidence preparation")
    print("Fixture:", FIXTURE, " |  1.26 -> 1.29  |  provider:", AdversarialProvider.name)
    print("=" * 78)

    print("\n[1] VERDICT / SCORE  (deterministic engine is source of truth)")
    print("    AI said:      verdict=ready score=100 confidence=100 (in narrative)")
    print(f"    Deterministic:verdict={det_verdict} score={det_score} confidence={det_confidence}")
    print(f"    AFTER MERGE:  verdict={merged.readiness.verdict.value} "
          f"score={merged.readiness.score} confidence={merged.readiness.confidence}")
    ok_scores = (merged.readiness.verdict.value == det_verdict
                 and merged.readiness.score == det_score
                 and merged.readiness.confidence == det_confidence)
    print(f"    RESULT:       {'UNCHANGED — model could not move them' if ok_scores else 'CHANGED (!!)'}")

    print("\n[2] INJECTED 'CRITICAL BLOCKING' FINDING (no citation, lies about origin)")
    if injected_from_llm is None:
        print("    AFTER MERGE:  finding DROPPED entirely")
        neutralized = True
    else:
        print("    AI said:      severity=critical  blocking=True  origin=deterministic")
        print(f"    AFTER MERGE:  severity={sev(injected_from_llm)}  "
              f"blocking={injected_from_llm.blocking}  origin={injected_from_llm.origin.value}")
        print(f"    label:        {injected_from_llm.description[:70]!r}")
        neutralized = (not injected_from_llm.blocking
                       and injected_from_llm.origin.value == "llm"
                       and injected_from_llm.severity.value in ("low", "info"))
        print(f"    RESULT:       {'NEUTRALIZED — non-blocking, demoted, re-labelled ungrounded' if neutralized else 'NOT fully neutralized (!!)'}")

    print("\n[3] FABRICATED CITATION  (model cited [DOC 99] which was never retrieved)")
    kept_refs = sorted(c.ref for c in merged.citations)
    print("    AI said:      citations_used=[99]")
    print("    Retrieved:    [1]")
    print(f"    AFTER MERGE:  citations kept={kept_refs}")
    print(f"    RESULT:       {'DROPPED — 99 discarded, only genuinely-retrieved refs remain' if 99 not in kept_refs else 'LEAKED (!!)'}")

    print("\n[4] BLOCKING FINDINGS THAT DECIDE THE GATE (must be deterministic-only)")
    final_blocking = [f.id for f in merged.findings if f.blocking]
    print(f"    Deterministic blocking ids: {det_blocking}")
    print(f"    Final blocking ids:         {final_blocking}")
    print(f"    RESULT:       {'IDENTICAL — the model added zero blockers' if final_blocking == det_blocking else 'CHANGED (!!)'}")

    print("\n[5] GROUNDING RATIO (measured on the merged narrative, not promised)")
    print(f"    grounding_ratio = {merged.llm.grounding_ratio}  (fraction of substantive"
          " sentences carrying a [DOC n] citation)")

    print("\n" + "=" * 78)
    all_ok = ok_scores and neutralized and 99 not in kept_refs and final_blocking == det_blocking
    print("OVERALL:", "ALL TRUST RULES HELD — the model altered narrative only, never the verdict."
          if all_ok else "TRUST BREACH DETECTED — investigate.")
    print("=" * 78)


if __name__ == "__main__":
    main()
