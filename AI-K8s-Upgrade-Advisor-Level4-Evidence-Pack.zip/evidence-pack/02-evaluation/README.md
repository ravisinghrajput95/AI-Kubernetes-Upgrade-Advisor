# 02 — Evaluation

**Criterion:** Explicit assessment and validation of AI outputs.
**Strength in this pack:** Strong.

The central engineering claim of this project is: *an LLM is excellent at explaining and
planning, and unfit to be a source of truth for version compatibility.* The whole system is
built so AI output is **validated after the model responds, not trusted on faith.** This
folder proves that claim two ways — with a live adversarial probe, and with real assessment
outputs from the tool.

---

## 1. The trust-boundary probe (flagship artifact)

`harness/trust_boundary_demo.py` + `harness/trust-boundary-demo-output.txt`
*Generated during evidence preparation.*

This is the single strongest evaluation artifact in the pack. It builds a **real**
deterministic assessment from the bundled EKS fixture, then feeds an **adversarial** LLM
response — one that hallucinates a `CRITICAL`, `blocking` finding with no citation, lies
about that finding's origin, tries to overwrite the verdict/score in its narrative, and
cites a document (`[DOC 99]`) that was never retrieved — through the **exact production
function the live gpt-4o path uses** (`run_llm_analysis` in
`../supporting-evidence/source/advisor-trust-boundary.py`).

Nothing about the safety behaviour is hand-asserted. Every "AFTER" value is read back off
the real merged report object. The captured result:

| The model tried to… | What the trust boundary did (real output) |
|---|---|
| Claim verdict `ready`, score `100` | **Ignored** — verdict stayed `not-ready`, score `47`, confidence `94` |
| Inject a `CRITICAL` `blocking` finding | **Neutralized** — forced `origin=llm`, `blocking=False`, demoted to `low`, re-labelled `[ungrounded — model reasoning without document citations]` |
| Cite fabricated `[DOC 99]` | **Dropped** — logged `llm_invalid_citations_dropped refs=[99]`; kept citations `[]` |
| Add a blocker that decides the gate | **Failed** — final blocking-finding set identical to deterministic (`[]`) |

> **AI said** the cluster was ready with an invented blocker.
> **Validation showed** the deterministic engine's verdict and blocker set were untouched.
> **Therefore** only the (measured, low-grounding) narrative was affected — exactly the
> blast radius the architecture intends.

This maps directly to the criterion: the tool does not blindly trust AI output; it
structurally constrains it and measures the residue.

## 2. Real assessment outputs across scenarios

`scenarios/` *Generated during evidence preparation* — produced by running the shipped CLI
over the bundled offline fixture (`tests/fixtures/eks_1_26.json`), no cluster or network.

| File | Scenario | What it demonstrates |
|---|---|---|
| `A-eks-1.26-to-1.29-deterministic.md` / `.html` | 3-hop EKS upgrade | Multi-hop path detection, 7 deterministic findings, readiness **capped at 95** because *unverified risks remain* — an honesty control |
| `B-beyond-horizon-cap-1.26-to-1.40.md` | Target beyond known tables | The **knowledge-horizon cap (70)** fires: "an empty findings list for those minors means unexamined, not safe." AI/heuristics are *not* allowed to guess past the reviewed data |
| `C-single-hop-1.28-to-1.29.md` | Adjacent single hop | Contrast case — different finding set and score from the same fixture, proving the analysis is input-driven, not canned |

The **grounding ratio** (`llm.grounding_ratio` in every report and a Prometheus histogram)
turns each production run into an eval sample: the fraction of substantive narrative
sentences carrying a `[DOC n]` citation is measured, logged, and warns when low — see
`../supporting-evidence/source/test_ai_quality.py::TestGroundingRatio` for the regression
tests. (In these three *dry-run* scenarios the narrative is deterministic-only, so the ratio
is 0.0 by construction; the metric mechanism is proven by those unit tests and by the probe.)

## Why this is Level-4 evaluation

Level 3 checks AI output by eye. Level 4 builds **repeatable, automated validation** into
the system: a code-enforced trust boundary, a measured grounding metric, schema validation
with a repair round-trip, and regression tests that fail loudly if any of it weakens
(`test_ai_quality.py`, `test_llm_merge.py`). The probe here shows that machinery working
against a deliberately hostile input.
