# 04 — Operationalization

**Criterion:** AI embedded into repeatable workflows.
**Strength in this pack:** Strong.

The AI here is not a notebook experiment. It is one stage of a **repeatable, deployable,
tested engineering pipeline** that runs identically from a laptop, a container, or CI.

---

## The repeatable pipeline

Every assessment — CLI or API — runs the same ordered stages (see `architecture/`):

```
Cluster snapshot ─▶ Profiler ─▶ Deterministic engines ─▶ Risk engine (scores/caps)
                                        │
              RAG retrieval (BM25+dense→RRF→version filter→rerank→MMR)
                                        ▼
                    LLM advisor (schema-validated, trust-boundary merge, grounding measured)
                                        ▼
                 AssessmentReport ─▶ Markdown / HTML / JSON ─▶ Human review & gate
```

The AI stage is a **bounded, optional, observable** step in that flow: it degrades to a
deterministic report if the LLM is absent or fails, its latency/tokens/cost/grounding are
recorded per stage, and its output is gated by exit-code thresholds (`--fail-on`).

## Evidence in this folder

| Artifact | Type | What it shows |
|---|---|---|
| `pytest-coverage-run.txt` | *Generated during evidence prep* | The full **203-test** suite passing in <3s at **87.31%** coverage, with an enforced 80% floor. Offline — no cluster, no network, no LLM. The AI-merge logic (`advisor.py`) is at **95%**. |
| `ci-workflow.yml` | *(from the repository)* | The AI workflow is operationalized in CI: lint, 4-version pytest matrix **with a coverage floor**, helm-lint, dependency audit, Trivy image scan, a **static-table freshness canary** (warns when the knowledge tables are >90 days stale), and a **dogfood job** that runs the advisor against the fixture and publishes the report as a build artifact. |

## Repeatability beyond this pack *(from the repository, referenced not duplicated)*

- **Reproducible AI behaviour offline** — the LLM path is fully exercised in tests via fake
  providers, so the trust-boundary and grounding logic run deterministically in CI on every
  push, on Python 3.11–3.14.
- **Shipped as a service** — published container image + Helm chart, stateless replicas,
  rate limiting / idempotency / load shedding, SLO alert rules, and a DR runbook
  (`docs/operations.md` in the repo).
- **Operational observability of the AI stage** — Prometheus metrics for per-stage latency,
  LLM tokens, estimated cost, and grounding ratio; structured logs with request-ID
  correlation; optional OpenTelemetry spans.
- **A maintenance cadence** — a documented release checklist refreshes the static knowledge
  tables each Kubernetes minor, with the CI freshness canary as the reminder. The AI's
  ground truth is *maintained*, not left to rot.

## Why this is Level-4 operationalization

Anyone can call an API once. Level 4 is when the AI is a **governed production stage**:
optional, observable, cost-accounted, regression-tested, degradable, and wired into CI/CD
and a release cadence. To reproduce the generated artifacts here yourself, follow
`../reproducibility/README.md`.
