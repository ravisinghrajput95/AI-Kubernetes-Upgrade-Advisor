# 05 — Judgment

**Criterion:** Intentional tradeoff and governance decisions.
**Strength in this pack:** Strong.

This is the criterion that most clearly separates "used an AI" from "engineered *with* AI."
Every decision below is a **real, documented** choice made in this project — four are
recorded as Architecture Decision Records (`../supporting-evidence/adr/`), the rest are
visible in code and commit history. None are invented for this pack.

The through-line: **AI is deliberately scoped to where it is strong (explaining, planning,
narrating) and deliberately excluded from where it is dangerous (deciding compatibility
truth, setting the gate).**

---

### Decision 1 — AI vs. deterministic: who owns the truth?

- **Decision:** Should the LLM produce findings/scores/verdict, or only narrate them?
- **Options:** (a) LLM produces the whole assessment (the v1 design); (b) deterministic
  engines produce all facts, LLM narrates.
- **Trade-off:** (a) is faster to build and more flexible, but compatibility facts can be
  hallucinated with no way to tell, and prose parsing is fragile. (b) requires maintaining
  static lifecycle tables per release.
- **Chosen:** (b) — deterministic-first, LLM-second.
- **Reason:** "The set of removed Kubernetes APIs per version is finite and public; asking a
  language model to rediscover it per assessment is strictly worse than a table." That
  maintenance cost *is* the product's accuracy.
- **Evidence:** `../supporting-evidence/adr/0001-deterministic-first-llm-second.md`;
  enforced in `advisor-trust-boundary.py`; proven by `../02-evaluation/`.

### Decision 2 — Hallucination containment: enforce after, not before

- **Decision:** How do you stop the model fabricating a blocker or a citation?
- **Options:** (a) prompt the model to behave and hope; (b) enforce the trust boundary in
  code after the model responds.
- **Trade-off:** (a) is zero extra code but unprovable and brittle; (b) is more code but
  gives a hard, testable guarantee.
- **Chosen:** (b) — "the trust boundary is enforced *after* the model responds, not by
  prompt hope." Model findings are forced non-blocking, severity-capped, deduplicated, and
  ungrounded ones are demoted and labelled; fabricated citations are dropped.
- **Reason:** Prompt instructions are best-effort; a merge function is a guarantee you can
  regression-test.
- **Evidence:** `../02-evaluation/harness/` (live probe); `advisor-trust-boundary.py`;
  `test_ai_quality.py`.

### Decision 3 — Human-in-the-loop: recommend, never auto-execute

- **Decision:** Should the advisor apply upgrades or only advise?
- **Options:** (a) auto-remediate/upgrade; (b) produce a gated recommendation for a human.
- **Trade-off:** automation is attractive but a wrong production upgrade is destructive and
  often irreversible (managed control planes cannot downgrade).
- **Chosen:** (b) — output is a report + verdict + exit-code gate (`--fail-on`), consumed by
  a human or a pipeline that a human owns. The tool never touches the cluster's control plane.
- **Reason:** The blast radius of a bad call is a production outage; the appropriate role for
  an AI-assisted tool there is decision *support*, with the irreversible action behind human
  judgment.
- **Evidence:** CLI/report design; `../02-evaluation/scenarios/` verdicts; README "rollback
  reality (managed control planes can't downgrade)."

### Decision 4 — Honesty over confidence: caps instead of guesses

- **Decision:** What does the tool do when it lacks evidence?
- **Options:** (a) stay silent / assume safe; (b) explicitly cap readiness and say so.
- **Trade-off:** (a) yields cleaner-looking reports; (b) yields lower scores that need
  explaining — but tells the truth.
- **Chosen:** (b) — missing evidence *caps* readiness (95 when unverified risks remain);
  targets beyond the reviewed tables trigger a **knowledge-horizon cap (70)**: "an empty
  findings list for those minors means unexamined, not safe."
- **Reason:** In upgrade planning, a false "ready" is far more expensive than a cautious
  "not sure." Honesty is treated as a feature, and the AI is never allowed to paper over the gap.
- **Evidence:** `../02-evaluation/scenarios/B-beyond-horizon-cap-1.26-to-1.40.md`;
  ADR-0001 consequences.

### Decision 5 — Structured output: schema, not prose parsing

- **Decision:** How does the machine consume the model's output?
- **Options:** (a) regex free-form markdown; (b) require one schema-validated JSON object.
- **Trade-off:** (a) is easy initially but silently breaks on any phrasing change; (b) needs
  a schema + repair path.
- **Chosen:** (b) — JSON-object response, one repair round-trip on validation failure, then
  graceful degradation; all renderers are pure functions of the typed report.
- **Reason:** A phrasing change should never flip a verdict badge; the JSON report is a
  stable machine interface for CI gating.
- **Evidence:** `../supporting-evidence/adr/0002-structured-llm-output.md`;
  `_validate_with_repair` in `advisor-trust-boundary.py`.

### Decision 6 — Cost & model governance

- **Decision:** Which model, and how is spend controlled?
- **Options:** larger frontier model vs. `gpt-4o`; unbounded calls vs. governed calls.
- **Trade-off:** the model only narrates over a pre-computed report, so raw reasoning horsepower
  matters less than reliable JSON + good instruction-following at low latency/cost.
- **Chosen:** `gpt-4o` for narration, **plus** operational cost controls: a compact schema
  (22% fewer tokens/call), per-report token/cost accounting, an idempotency cache so retry
  storms don't multiply spend, and rate limiting.
- **Reason:** The AI's job is bounded, so pay for reliability and govern the budget rather
  than buy maximum reasoning.
- **Evidence:** commit `77f9c75` (compact schema, cost accounting); `2da651f` (idempotency);
  `test_ai_quality.py::TestCostAccounting`.

### Decision 7 — Security & data handling

- **Decision:** How is sensitive cluster/credential data handled?
- **Chosen:** snapshots are local JSON the user controls; outbound doc fetches are restricted
  to a curated **HTTPS allow-list**; optional shared-secret API key + CORS allow-list;
  non-root container (uid 10001); request body-size guard; KB metadata is JSON, not pickle.
  No kubeconfig or secret is embedded in reports.
- **Reason:** An upgrade advisor sees privileged cluster data; the model should receive only
  the derived, non-secret profile, and the tool should not become an exfiltration path.
- **Evidence:** README "Security posture"; CI CodeQL/Trivy/pip-audit; commit `a3b0147`
  (pickle→JSON, HTTPS enforcement).

---

## Why this is Level-4 judgment

Each decision names the alternative that was *rejected* and *why*, ties to a cost, and is
backed by an artifact — ADR, code, or commit. That is governance: the AI's role was
**bounded by intent**, not by accident, and the boundaries are written down where a future
engineer (or auditor) can find them.
