# Why this evidence supports AI Proficient (Level 4)

This document makes the Adaptive→Proficient argument explicitly, and maps it to artifacts. It
does **not** claim the assessment is guaranteed to pass — it argues why the evidence is strong.

## The distinction, applied

**AI Adaptive (Level 3)** — AI is used effectively to assist the work. The engineer prompts
well, evaluates the answer by eye, iterates in a chat, and ships the result.

**AI Proficient (Level 4)** — AI is *deliberately integrated into an engineering workflow*
with structured interaction, explicit validation, refinement, operationalization, governance,
and preserved human judgment. The AI stops being a tool the engineer uses and becomes a
**capability the engineer bounds, measures, and governs**.

The single clearest signal that this project is L4 rather than L3: **the AI's output is
constrained and validated by code, and the constraint is regression-tested.** An L3 project
would trust the model's findings and eyeball them. This project assumes the model will
sometimes hallucinate a blocker or a citation, and makes that *structurally unable to change
the decision* — then proves it with an adversarial probe.

## Behaviour-by-behaviour mapping

| Level-4 behaviour | Does this project show it? | Evidence |
|---|---|---|
| **Structured interaction**, not ad-hoc prompting | Yes — a codified prompt *contract* with rules, structured input, schema output, and an automated repair turn | `01-interaction/` |
| **Explicit validation** of AI output | Yes — a code-enforced trust boundary + measured grounding ratio, demonstrated against adversarial input | `02-evaluation/` |
| **Refinement** across generations, not one-shot | Yes — six named review rounds hardening AI reliability, each pinned by tests | `03-refinement/` |
| **Operationalized** into a repeatable workflow | Yes — bounded/optional/observable AI stage in a CI-tested, deployable pipeline | `04-operationalization/` |
| **Governance & tradeoffs** documented | Yes — 7 decisions + 4 ADRs naming rejected alternatives and costs | `05-judgment/` |
| **Human judgment preserved** for irreversible actions | Yes — recommend-never-execute; human owns the gate | `05-judgment/` Decision 3 |
| **Cost/model governance** | Yes — bounded model choice + compact schema + cost accounting + idempotency | `05-judgment/` Decision 6 |
| **Failure handling / degradation** | Yes — LLM absent/invalid → deterministic report still ships | ADR-0001; `architecture/` |

## What would make it *weaker* than L4 — and why those don't apply here

- *"The AI is doing the real analysis."* — It isn't. Deterministic engines own every fact,
  score, and verdict; the AI narrates. Removing the AI still yields a complete report
  (dry-run mode, offline tests).
- *"Validation is just a prompt asking nicely."* — It isn't. The boundary is a merge function
  enforced after the model responds, with tests; the probe shows it defeating a hostile input.
- *"Improvement is asserted, not shown."* — It's shown in diffs and a rising test count
  (123→203), with the specific hardening commit isolated.

## Honest calibration

The one dimension where this pack is **Moderate rather than Strong** is *live interaction
transcripts* — the original human↔AI build conversations were not preserved, and this pack
refuses to fabricate them (`evidence-gaps.md`). The interaction criterion is instead carried
by the *codified* protocol and the ADR trail, which is defensible and arguably more durable,
but an evaluator who specifically wants to see raw iterative dialogue should read
`evidence-gaps.md`, which describes exactly how to capture that going forward.

On balance: four of five criteria are backed by Strong, reproducible, non-fabricated
evidence, and the fifth is Moderate with an honest account of the gap. That is a credible
Level-4 submission.
