# Architecture — with the AI / deterministic boundary marked

The defining property of this system is the **trust boundary** between deterministic truth
and AI narration. The diagram marks every stage as either 🟦 **deterministic (source of
truth)** or 🟨 **AI-driven (narration/planning, constrained)**.

## Diagram (renders on GitHub / any Mermaid viewer)

```mermaid
flowchart TB
    subgraph IN["Inputs — deterministic"]
        K["kubectl -o json<br/>(versions, nodes, APIs, CRDs, webhooks, PDBs)"]
        H["helm list + get manifest"]
    end
    K --> SN["ClusterSnapshot (local JSON)"]
    H --> SN

    subgraph DET["DETERMINISTIC engines — SOURCE OF TRUTH"]
        SN --> PR["Profiler<br/>(distribution, components, workloads)"]
        PR --> AN["API lifecycle · version skew · component compat<br/>webhooks · CRD storage debt · helm manifest scan"]
        AN --> RK["Risk engine<br/>readiness score · caps (unverified=95, horizon=70)<br/>confidence · verdict · blocking findings"]
    end

    subgraph RAG["DETERMINISTIC RAG engine — grounded evidence"]
        SRC["CHANGELOGs · compat matrices<br/>(curated HTTPS allow-list)"] --> KB[("Manifest-versioned<br/>vector + BM25 store")]
        KB --> RET["BM25 + dense → RRF<br/>hard version filter → rerank → MMR"]
    end

    RK -->|"fixed facts, scores, verdict<br/>(model may NOT change these)"| LLM
    RET -->|"numbered [DOC n] context"| LLM

    subgraph AI["AI advisor — narration & planning (constrained)"]
        LLM["LLM (gpt-4o)<br/>schema-validated JSON output<br/>one repair round-trip"]
        LLM --> MERGE["Trust-boundary merge<br/>scores/verdict: deterministic wins<br/>model findings: non-blocking, capped, deduped<br/>ungrounded findings: demoted + labelled<br/>fabricated citations: dropped<br/>grounding ratio: measured"]
    end

    MERGE --> REP["AssessmentReport (typed)"]
    RK -.->|"LLM absent/failed →<br/>deterministic report ships"| REP
    REP --> OUT["Markdown · HTML · JSON"]
    REP --> GATE["HUMAN review + exit-code gate (--fail-on)"]
    GATE --> DEC["Upgrade decision (human-owned, never auto-executed)"]
```

## The boundary in one sentence

Everything that decides *whether the upgrade is safe* (findings, scores, verdict, blockers)
is 🟦 deterministic and provable from cluster data + sourced static tables. Everything the
🟨 AI produces (executive summary, risk story, sequenced runbook, downtime reasoning) is
narration layered **on top of** that truth, validated after the fact, and incapable of
moving the gate. If the AI stage is removed entirely, the system still produces a complete,
CI-gateable report — proven by dry-run mode and the offline test suite.

## Component → trust classification

| Component | Trust | Role |
|---|---|---|
| Snapshot collector, Profiler | 🟦 Deterministic | Extract measured cluster facts |
| API lifecycle / skew / compat / webhooks / CRD / helm engines | 🟦 Deterministic | Produce all findings |
| Risk engine | 🟦 Deterministic | Scores, caps, confidence, verdict, blocking set |
| RAG retrieval (BM25+dense, version filter, rerank, MMR) | 🟦 Deterministic pipeline | Supplies grounded, cited evidence |
| LLM advisor | 🟨 AI | Narrative, sequencing, runbook, downtime reasoning |
| Trust-boundary merge | 🟦 Deterministic guard | Enforces the boundary on AI output |
| Renderers (MD/HTML/JSON) | 🟦 Deterministic | Pure functions of the typed report |
| Human review + gate | 🧑 Human | Owns the irreversible decision |

> **Note on `architecture.png`:** this diagram is provided as Mermaid (renders inline on
> GitHub and in most Markdown viewers) rather than a binary PNG, so it stays diff-able and
> text-auditable. The repository's `docs/architecture.md` carries the same boundary in prose
> and sequence form.
