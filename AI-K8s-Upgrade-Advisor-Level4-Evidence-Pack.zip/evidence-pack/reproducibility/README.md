# Reproducibility Guide

Every artifact in this pack marked *Generated during evidence preparation* can be regenerated
by you, offline, from the public repository. No credentials, no production cluster, no network,
and no LLM API key are required for any of it.

## Prerequisites

- Python 3.11–3.14 (the project's CI matrix; 3.14 was used to generate this pack)
- `git`
- ~200 MB disk for a virtualenv
- **No** kubeconfig, cloud credentials, or `OPENAI_API_KEY` needed for the reproductions below

## Environment setup

```bash
git clone https://github.com/ravisinghrajput95/AI-Kubernetes-Upgrade-Advisor.git
cd AI-Kubernetes-Upgrade-Advisor
python -m venv .venv && source .venv/bin/activate
pip install -e ".[api,dev]"
```

## 1. Reproduce the test-suite + coverage run

Regenerates `04-operationalization/pytest-coverage-run.txt`.

```bash
pytest --cov --cov-report=term-missing
```

**Expected:** 203 passed in <3s; `Required test coverage of 80.0% reached. Total coverage:
~87%`. (`advisor.py` — the AI-merge/trust-boundary module — reports ~95%.)

## 2. Reproduce the scenario assessments

Regenerates `02-evaluation/scenarios/`. All use the bundled offline snapshot — no live cluster.

```bash
# A — 3-hop EKS upgrade (unverified-risk cap at 95)
k8s-upgrade-advisor assess -s 1.26 -t 1.29 \
  --snapshot tests/fixtures/eks_1_26.json --dry-run --fail-on never \
  --md A.md --html A.html

# B — target beyond the knowledge horizon (cap at 70)
k8s-upgrade-advisor assess -s 1.26 -t 1.40 \
  --snapshot tests/fixtures/eks_1_26.json --dry-run --fail-on never --md B.md

# C — single adjacent hop (contrast case)
k8s-upgrade-advisor assess -s 1.28 -t 1.29 \
  --snapshot tests/fixtures/eks_1_26.json --dry-run --fail-on never --md C.md
```

**Expected headlines:** A → `NOT READY`, readiness `47/100` (cap 95); B → `BLOCKED`,
readiness `6/100` (cap 70, "beyond the reviewed knowledge horizon (1.36)"); C → `NOT READY`,
readiness `52/100`, a *different* finding set from A (proving input-driven analysis).

> Note: `--dry-run` runs deterministic-only, so the grounding ratio in these reports is 0.0
> by construction. To produce a live-AI report with a non-trivial grounding ratio, set
> `OPENAI_API_KEY` and drop `--dry-run` (see `../evidence-gaps.md` I1/I3).

## 3. Reproduce the trust-boundary probe (flagship)

Regenerates `02-evaluation/harness/trust-boundary-demo-output.txt`. The probe script is
included in this pack at `../02-evaluation/harness/trust_boundary_demo.py`; run it from the
repo root with the venv active:

```bash
python /path/to/evidence-pack/02-evaluation/harness/trust_boundary_demo.py
```

**Expected:** `OVERALL: ALL TRUST RULES HELD — the model altered narrative only, never the
verdict.` The script builds a real deterministic report, feeds an adversarial (hallucinated,
uncited, verdict-overriding) LLM response through the real `run_llm_analysis`, and prints the
before/after for verdict, score, the injected blocker, and the fabricated citation. It also
emits the real log line `llm_invalid_citations_dropped refs=[99]`.

## Validation checklist

| You should see | Confirms |
|---|---|
| 203 tests pass, ~87% coverage | Operationalization / refinement pinned by tests |
| Scenario B capped at 70 with a horizon finding | Honesty control (judgment/evaluation) |
| Probe prints "ALL TRUST RULES HELD" | The trust boundary defeats adversarial AI output (evaluation) |
| Scenarios A and C differ | Analysis is input-driven, not canned |

## Security note

This guide requires **no secrets**. Do not add a real `OPENAI_API_KEY`, kubeconfig, or cloud
credential to reproduce the offline artifacts — none of them need one. If you choose to
exercise the live-AI path (optional), keep the key in your environment, never in a file that
could end up in a submission.
