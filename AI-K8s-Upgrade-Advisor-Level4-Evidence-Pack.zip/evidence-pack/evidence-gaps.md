# Evidence Gaps — an honest account

The no-fabrication rule cuts both ways: this pack neither invents evidence nor hides what is
missing. Below is a brutally honest inventory, prioritized, each with a concrete action to
close it.

## Critical gaps
*(would materially weaken the Level-4 case if an evaluator weights them heavily)*

### C1 — No preserved human↔AI build transcripts
The original conversations in which the tool was built with AI assistance were not saved.
This is the single genuine weakness of the **Interaction** criterion.
- **Why it matters:** some evaluators read "structured iterative collaboration" as literally
  wanting to see the dialogue — problem → AI approach → human critique → improved output.
- **What this pack does instead (not a substitute, a mitigation):** proves the *codified*
  interaction protocol (the production prompt contract + repair round-trip) and the ADR trail
  that shows the interaction design was deliberate. See `01-interaction/`.
- **Action to close:** capture one real, end-to-end AI-assisted work session on this repo
  (e.g. adding the deferred "etcd version/skew awareness" backlog item) with the full
  prompt/response/critique/refine thread saved as `01-interaction/session-transcript.md`.
  This requires a fresh working session and was out of scope for packaging existing evidence.

## Important gaps
*(strengthen the pack noticeably but aren't disqualifying)*

### I1 — No live LLM run captured in this pack
The trust-boundary probe uses a *fake adversarial provider* against the **real merge code**,
which is actually the more rigorous test (it can force worst-case input). But there is no
captured live `gpt-4o` assessment here.
- **Why:** running the live path needs a real `OPENAI_API_KEY`; none is included (correctly —
  see Security below), and the previously-used key was revoked.
- **Mitigation:** the repository's `examples/kind-1.32-to-1.36-ai.md` contains a real,
  cluster-validated grounded gpt-4o run (referenced, not duplicated, to keep the pack lean).
- **Action to close:** set `OPENAI_API_KEY`, drop `--dry-run`, and save the resulting report
  into `02-evaluation/scenarios/` labelled as a live run.

### I2 — Architecture provided as Mermaid, not PNG
`architecture/architecture.md` is a Mermaid diagram (renders on GitHub/most viewers) rather
than a binary PNG, chosen so it stays text-auditable and diff-able.
- **Action to close:** render the Mermaid to `architecture.png` with any Mermaid renderer if
  the portal requires a raster image.

### I3 — Grounding ratio in the generated scenarios is 0.0
The scenario reports are **dry-run (deterministic-only)**, so no narrative is generated and
the grounding ratio is trivially 0.0. The *mechanism* is proven by the unit tests
(`test_ai_quality.py::TestGroundingRatio`, which assert 1.0 / 0.5 / 0.0 cases) rather than by
a live scenario in this pack.
- **Action to close:** same as I1 — a live run would populate a real, non-trivial grounding ratio.

## Nice-to-have
*(polish; low impact on the L4 decision)*

- **N1 — A short screen recording** of the CLI producing an assessment, for evaluators who
  prefer video. Action: record `k8s-upgrade-advisor assess … --dry-run` with the bundled fixture.
- **N2 — A metrics screenshot** (Prometheus grounding/cost histograms) showing the AI stage
  observed in a running instance. Action: `k8s-upgrade-advisor serve`, scrape `/metrics`,
  capture the `advisor_llm_*` series.
- **N3 — Deferred-backlog note as governance evidence.** The repo maintains a deliberately
  deferred backlog (etcd skew, live-LLM eval harness, Grafana dashboard). That "we chose not
  to build this yet" list is itself judgment evidence and could be surfaced explicitly.

## What is explicitly NOT a gap (guarding against over-claiming)

- The trust boundary, grounding measurement, horizon caps, and review-driven refinement are
  all **real and in the shipped code** — not aspirational.
- The 203-test suite, 87.31% coverage, and CI matrix are **real and reproducible** (`reproducibility/`).
- No metric, commit, test result, or decision in this pack is fabricated.
