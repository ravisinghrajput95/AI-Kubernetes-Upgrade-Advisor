# Evidence Matrix

Every criterion → the artifact that proves it → where it lives → what it demonstrates →
strength. Artifacts marked *(gen)* were **generated during evidence preparation** by real
work with the existing tool (reproducible via `reproducibility/`); all others are
pre-existing repository artifacts.

| Criterion | Evidence artifact | Location | What it demonstrates | Strength |
|---|---|---|---|---|
| **Interaction** | Production prompt contract (`prompts.py`) | `01-interaction/prompts/production-prompt-contract.py` | A codified, versioned protocol: role, grounding rules, structured input, schema-bound output | Strong |
| **Interaction** | Repair round-trip in merge code | `supporting-evidence/source/advisor-trust-boundary.py` (`_validate_with_repair`) | Iterative generate→critique→refine loop embedded in code | Strong |
| **Interaction** | Deterministic report fed to the model *(gen)* | `01-interaction/outputs/…feeds-the-llm.md` | The real input side of the collaboration | Moderate |
| **Interaction** | ADR-0002 structured output | `supporting-evidence/adr/0002-structured-llm-output.md` | The interaction contract was a deliberate design decision | Strong |
| **Evaluation** | **Trust-boundary probe** *(gen)* | `02-evaluation/harness/trust_boundary_demo.py` + `.txt` | Adversarial LLM output run through real merge code; verdict/score/blocker untouched, fabricated citation dropped | **Strong (flagship)** |
| **Evaluation** | Scenario A/B/C reports *(gen)* | `02-evaluation/scenarios/` | Input-driven results; unverified-risk cap (95); knowledge-horizon cap (70) | Strong |
| **Evaluation** | Grounding-ratio logic + tests | `supporting-evidence/source/test_ai_quality.py` | AI grounding measured per run and regression-tested, not assumed | Strong |
| **Evaluation** | Trust-boundary source | `supporting-evidence/source/advisor-trust-boundary.py` | The validation machinery itself, documented and enforced | Strong |
| **Refinement** | Review-driven commit trail | `03-refinement/review-driven-iteration-commits.txt` | 6 named review rounds, each fixing concrete issues, tests 123→203 | Strong |
| **Refinement** | Trust-boundary tightening diff | `03-refinement/diff-trust-boundary-tightening.patch` | Concrete before/after hardening of AI hallucination defense | Strong |
| **Refinement** | Coverage run showing tests pinning it *(gen)* | `04-operationalization/pytest-coverage-run.txt` | Each refinement locked by passing regression tests | Strong |
| **Operationalization** | 203-test coverage run *(gen)* | `04-operationalization/pytest-coverage-run.txt` | AI path exercised offline, 87.31% coverage, enforced floor | Strong |
| **Operationalization** | CI workflow | `04-operationalization/ci-workflow.yml` | AI embedded in CI: 4-version matrix, dogfood job, table-freshness canary | Strong |
| **Operationalization** | Architecture pipeline | `architecture/architecture.md` | AI is one bounded, degradable, observable stage of a repeatable flow | Strong |
| **Judgment** | 7-decision governance log | `05-judgment/README.md` | Intentional tradeoffs, each with rejected alternative + cost + evidence | Strong |
| **Judgment** | ADRs 0001–0004 | `supporting-evidence/adr/` | Load-bearing decisions recorded at the time, with consequences | Strong |
| **Judgment** | Architecture boundary map | `architecture/architecture.md` | Explicit AI vs deterministic classification per component | Strong |

## Coverage summary

| Criterion | Strength | Primary evidence |
|---|---|---|
| Interaction | **Moderate→Strong** | Codified prompt contract + repair loop + ADR-0002 (transcript gap acknowledged) |
| Evaluation | **Strong** | Live adversarial trust-boundary probe + scenario caps + grounding tests |
| Refinement | **Strong** | Six review rounds + concrete hardening diff + test growth 123→203 |
| Operationalization | **Strong** | Offline 203-test CI matrix + dogfood + freshness canary + service posture |
| Judgment | **Strong** | 7 documented decisions + 4 ADRs + marked architecture boundary |
