# Supporting Evidence

Referenced source-of-record artifacts, pulled directly from the repository. These back the
claims in the numbered evidence folders; they are copied verbatim (not summarized) so an
evaluator can inspect the primary material.

## `adr/` — Architecture Decision Records *(from the repository, `docs/adr/`)*

The four load-bearing design decisions, recorded at the time they were made (2026-07-18),
each with Context / Decision / Consequences:

| ADR | Decision | Criterion it most supports |
|---|---|---|
| `0001-deterministic-first-llm-second.md` | Deterministic engines own all facts/scores/verdict; LLM narrates | Judgment, Evaluation |
| `0002-structured-llm-output.md` | Schema-validated JSON output; renderers never parse prose | Interaction, Judgment |
| `0003-hybrid-retrieval-hard-version-filter.md` | BM25+dense RRF with a hard version metadata filter | Evaluation (grounding) |
| `0004-pluggable-embeddings-graceful-degradation.md` | Pluggable embeddings, degrade to hash+BM25 offline | Operationalization |

## `source/` — key source excerpts *(from the repository)*

- **`advisor-trust-boundary.py`** (`src/k8s_upgrade_advisor/llm/advisor.py`) — the heart of
  the system. The module docstring states the trust boundary; `_validate_with_repair`
  implements the repair round-trip; `_merge` enforces scores-are-fixed, findings-demoted,
  citations-validated, plan-structurally-checked; `_grounding_ratio` measures grounding. This
  is the exact code the `02-evaluation` probe exercises.
- **`test_ai_quality.py`** (`tests/test_ai_quality.py`) — the regression tests that pin the
  AI-quality behaviours: reranking, lost-in-the-middle context ordering, grounding-ratio
  computation, compact-schema token savings, and cost accounting. Evidence that the AI
  behaviour is *tested*, not just implemented.

## Not included here (referenced, to keep the pack lean and evaluator-friendly)

Per the "don't dump the whole repo" instruction, these live in the public repository and are
pointed to rather than copied:

- `docs/architecture.md`, `docs/rag.md`, `docs/operations.md`, `docs/development.md`
- The RAG retrieval implementation (`retrieval/`), knowledge store (`knowledge/`), and the
  deterministic analyzers (`analysis/`)
- The Helm chart (`deploy/helm/`), Dockerfile, and full CI (the CI file *is* included in
  `04-operationalization/` because it directly evidences operationalization)
- The real live-AI example report `examples/kind-1.32-to-1.36-ai.md`

Repository: `https://github.com/ravisinghrajput95/AI-Kubernetes-Upgrade-Advisor`
