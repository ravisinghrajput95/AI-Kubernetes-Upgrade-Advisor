# Assessment Narrative — AI-K8s Upgrade Advisor

*For a senior engineering evaluator assessing the transition from AI Adaptive (L3) to AI
Proficient (L4). This is not marketing; every claim points to a real artifact in this pack.*

---

## Executive summary

The AI-K8s Upgrade Advisor is a production-shaped platform that plans and gates Kubernetes
cluster upgrades. Its defining engineering idea is a **trust boundary**: deterministic
engines own every compatibility fact, score, and verdict; an LLM is scoped to narration,
sequencing, and runbook refinement *on top of* that truth, and its output is **validated in
code after it responds** — not trusted on faith.

That design is the reason this project is strong Level-4 evidence. It is not "an app that
calls an LLM." It is an application where AI is a **governed engineering capability**:
bounded by intent, constrained by a testable merge function, measured by a grounding metric,
regression-tested in CI across four Python versions, and shipped as an observable, degradable
service. The AI can improve a report; it structurally cannot make an unsafe upgrade look safe.

The project is real: 30 commits, 8 tagged releases (June–August 2026), evolved through named
review rounds. To close the gaps a static repo can't fill, this pack also includes work
performed **now** with the existing tool — the 203-test suite run, real assessments across
three scenarios, and a trust-boundary probe that pushes an adversarial LLM response through
the actual production merge code. Those are labelled *Generated during evidence preparation*
and are reproducible via `reproducibility/`.

---

## Interaction — structured iterative AI collaboration

The AI collaboration is **codified into a contract**, not left to ad-hoc chatting. The
production prompt (`01-interaction/prompts/production-prompt-contract.py`) defines a role,
four non-negotiable rules (grounding, fixed scores, plan realism, JSON-only), a fully
structured input (measured profile + deterministic findings marked *source of truth* +
explicit unknown risks + numbered `[DOC n]` documents), and a schema-bound output. The loop
is iterative *by construction*: a repair round-trip shows the model its own validation errors
and asks for a correction before degrading gracefully.

- **See:** `01-interaction/README.md`, the prompt contract, and the deterministic report that
  feeds the model (`01-interaction/outputs/`).
- **Honest limit:** no original human↔AI chat transcripts were preserved; this pack does not
  fabricate them (`evidence-gaps.md`). The codified, reproducible protocol is offered instead —
  the interaction as it runs in production, every time.

## Evaluation — explicit assessment and validation of outputs

This is the strongest section. The flagship artifact
(`02-evaluation/harness/trust_boundary_demo.py` + captured output) runs an **adversarial**
LLM response — hallucinated `CRITICAL` blocking finding, no citation, verdict-override
attempt, fabricated `[DOC 99]` — through the **real** `run_llm_analysis`. Captured result:
the verdict stayed `not-ready`, the score stayed `47`, the injected blocker was demoted to
`low`/non-blocking and re-labelled `[ungrounded]`, and the fabricated citation was dropped
(`llm_invalid_citations_dropped refs=[99]`). *AI said ready; validation showed the gate was
untouched; therefore only the narrative was affected.*

Alongside it, three real assessments (`02-evaluation/scenarios/`) show input-driven output,
the **unverified-risk cap (95)**, and the **knowledge-horizon cap (70)** — the tool refusing
to imply safety it can't prove. Grounding ratio is measured on every run and regression-tested.

- **See:** `02-evaluation/README.md`.

## Refinement — meaningful improvement over generations

The git history is a refinement log (`03-refinement/`). Six named review rounds each fixed
concrete problems and *increased AI reliability* — e.g. the SIG-accuracy round corrected a
staged cloud-provider removal that "missed the AWS breakage by four minors," and the
AI-quality round tightened the trust boundary so ungrounded model findings are demoted and
labelled (`03-refinement/diff-trust-boundary-tightening.patch`). Every round is pinned by new
tests (123 → 203) and the improvement in `02-evaluation` is the *result* of that exact diff.

- **See:** `03-refinement/README.md`.

## Operationalization — AI embedded in a repeatable workflow

The AI is one **bounded, optional, observable stage** of a pipeline that runs identically
from laptop, container, or CI. Evidence: the full 203-test suite passing at 87.31% coverage
with an enforced floor (`04-operationalization/pytest-coverage-run.txt`), and a CI workflow
(`ci-workflow.yml`) that runs the AI path across Python 3.11–3.14, dogfoods the advisor as a
build artifact, and includes a **static-table freshness canary** so the AI's ground truth is
maintained, not left to rot. In production it ships as a container + Helm chart with cost
accounting, idempotency, rate limiting, SLO alerts, and OTel traces on the AI stage.

- **See:** `04-operationalization/README.md`.

## Judgment — intentional tradeoffs and governance

Seven real, documented decisions (`05-judgment/`), four of them formal ADRs, each naming the
rejected alternative and its cost: deterministic-first ownership of truth; hallucination
containment enforced *after* the model, not by prompt hope; recommend-never-auto-execute for
an irreversible production action; honesty-caps over confident guesses; schema output over
prose parsing; bounded-model + cost governance; and privileged-data handling. The consistent
principle: **AI is scoped to where it is strong and excluded from where it is dangerous** —
and that boundary is written down.

- **See:** `05-judgment/README.md`, `architecture/architecture.md`, `supporting-evidence/adr/`.

---

## Evidence-backed outcome

The engineering value is a Kubernetes upgrade advisor you can trust *because* it does not
trust its own AI further than the design allows. A language model makes the output readable,
sequenced, and actionable; deterministic engines and a code-enforced boundary make it
*correct and honest*. The candidate demonstrably treats AI as a capability to be bounded,
validated, measured, and governed — which is the behaviour Level 4 asks for. Where evidence
is missing, `evidence-gaps.md` says so plainly rather than inflating the claim.
