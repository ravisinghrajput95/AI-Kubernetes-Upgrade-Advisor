# 03 — Refinement

**Criterion:** Meaningful improvement over AI generations.
**Strength in this pack:** Strong.

Refinement means the output got materially better through deliberate iteration — not a
one-shot generation accepted as-is. This project's git history *is* a refinement log: it
evolved through **explicitly review-driven rounds**, each committed separately, each fixing
concrete problems found by critique.

---

## The review-driven iteration trail

`review-driven-iteration-commits.txt` *(from the repository — full messages + file stats)*

Six load-bearing iterations, in order, each a distinct review pass:

| Commit | Round | Representative improvement (real, from the message) |
|---|---|---|
| `522c765` | Production-readiness review | Added the **knowledge-horizon readiness cap** — "no silent false safety" when the target exceeds the reviewed tables; fixed EKS misclassification (`aws://` providerID alone no longer implies EKS) |
| `c41ae36` | Performance / hardening | Load shedding (503 instead of thread-starvation), **retrieval golden-set regression tests** with near-miss distractors so chunking/fusion changes fail loudly |
| `64b6f26` | **Kubernetes-domain accuracy (SIG-level review)** | Staged in-tree cloud-provider removal per provider — *"the previous single 1.31 entry missed the AWS breakage by four minors."* A precise, high-consequence correction |
| `77f9c75` | **AI-stack quality** | Tightened the trust boundary + added measured grounding (see diff below); compact schema saving 22% tokens per call |
| `2da651f` | SRE production readiness | Idempotency cache so retry storms stop multiplying LLM spend; PDB/HPA |
| `453b1d2` | Usage-evidence accuracy | Deprecated-API detection from what the cluster *requests* (`apiserver_requested_deprecated_apis`), not just what it serves — served ≠ used |

Each round increased **AI reliability**, not just features: horizon caps, grounding
measurement, trust-boundary demotion, and served-vs-used distinction all reduce the chance of
a confidently-wrong recommendation.

## The trust-boundary tightening — a concrete before/after

`diff-trust-boundary-tightening.patch` *(from the repository — `git show 77f9c75 -- llm/advisor.py`)*

The clearest single refinement of the AI layer. **Before**, an LLM-added finding was merely
forced non-blocking and capped at HIGH. **After**, the diff adds:

```python
valid_refs = {c.ref for c in citations}
...
grounded = any(ref in valid_refs for evidence in finding.evidence
               for ref in evidence.citation_refs)
if not grounded and finding.severity.rank < Severity.LOW.rank:
    finding.severity = Severity.LOW
    finding.description = "[ungrounded — model reasoning without document citations] " + ...
```

The improvement: *citation-less model findings are now treated as speculation* — demoted and
labelled — instead of being trusted at HIGH. The commit shipped **14 new tests** to lock the
behaviour in. This is precisely "the AI output was improved through a deliberate, validated
change," and `02-evaluation`'s probe demonstrates the *result* of this exact change working.

## How the refinement was validated

Every round in the table above ends with a test-count increase (123 → 136 → 163 → 178 → …→
203) and passing CI. Refinements to AI behaviour are not asserted prose — they are pinned by
regression tests (`test_ai_quality.py`, `test_llm_merge.py`, `test_k8s_domain.py`) that fail
if the improvement regresses. Validation evidence: `../04-operationalization/pytest-coverage-run.txt`.
