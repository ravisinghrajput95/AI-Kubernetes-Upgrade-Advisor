# 01 — Interaction

**Criterion:** Structured iterative AI collaboration.
**Strength in this pack:** Moderate → Strong (structural evidence strong; live-transcript
evidence is an acknowledged gap — see `../evidence-gaps.md`).

Level-4 interaction is not "I asked an AI and pasted the answer." It is a **designed,
repeatable protocol** for how a machine and a model exchange work, with the human deciding
the contract. This project's AI collaboration is codified into a contract rather than left
to ad-hoc chatting — which is the more durable form of the same behaviour.

---

## The production prompt contract

`prompts/production-prompt-contract.py` *(from the repository —
`src/k8s_upgrade_advisor/llm/prompts.py`)*

This is the actual, versioned prompt the system uses every run. It encodes a structured
interaction protocol, not a one-off question:

- **Role + non-negotiable rules** (`SYSTEM_PROMPT`): grounding ("Never state a version
  compatibility from memory"), fixed scores ("Explain them; do not restate different
  numbers"), plan realism, and JSON-only output.
- **A fully structured input** (`build_user_prompt`): the upgrade request, measured cluster
  profile, deterministic findings (marked *source of truth — explain, never contradict*),
  fixed scores, explicit **unknown risks the model must surface honestly**, and numbered
  `[DOC n]` retrieved documents to cite.
- **A schema-bound output**: the model must return one JSON object matching `LLMAnalysis`;
  the schema is embedded (compacted to save ~22% tokens) directly in the prompt.

The interaction is *iterative by construction*: `build_user_prompt` feeds the deterministic
report to the model, and a **repair round-trip** (see
`../supporting-evidence/source/advisor-trust-boundary.py::_validate_with_repair`) shows the
model its own validation errors and asks for a correction — one automated follow-up turn,
then graceful degradation. That is a structured "generate → critique → refine" loop
embedded in code.

## The deterministic report the model receives

`outputs/deterministic-report-that-feeds-the-llm.md` *Generated during evidence preparation.*

This is the real input side of the collaboration — the fully-formed deterministic
assessment (verdict, findings, compatibility matrix, unknown risks) that becomes the model's
context. It shows that the human/engine does the analysis and the AI is scoped to narration
and planning **on top of** that analysis.

## Iterative evolution of the interaction itself

The *design* of this interaction was refined over multiple review rounds — the prompt moved
to a compact schema, the grounding contract was tightened, and the merge rules hardened. The
commit trail for that is in `../03-refinement/`, and the reasoning is recorded in
`../supporting-evidence/adr/0002-structured-llm-output.md`.

## Honest gap

No original human↔AI chat transcripts from the build were preserved. This pack does **not**
fabricate them. What it offers instead is the codified, reproducible interaction protocol
above — arguably stronger evidence than a chat log, because it is the interaction as it runs
in production, every time. See `../evidence-gaps.md` for how a transcript-backed version
could be captured going forward.
