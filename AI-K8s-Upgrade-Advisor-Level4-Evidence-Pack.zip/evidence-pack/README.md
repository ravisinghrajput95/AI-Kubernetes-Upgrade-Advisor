# AI Fluency Evidence Pack — AI-K8s Upgrade Advisor

**Candidate:** Ravi Rajput
**Current level:** AI Adaptive (Level 3 of 5)
**Target level:** AI Proficient (Level 4 of 5)
**Evidence subject:** AI Kubernetes Upgrade Advisor — an AI-assisted platform that plans,
validates, and gates Kubernetes cluster upgrades using deterministic compatibility
analysis plus RAG-grounded LLM reasoning.

---

## How to read this pack (5 minutes)

Start here, in order:

1. **`assessment-narrative.md`** — the evaluator narrative. What this project demonstrates
   for each of the five criteria, pointing at concrete artifacts.
2. **`evidence-matrix.md`** — one table mapping every criterion → artifact → location →
   what it proves → strength.
3. **`level-4-readiness.md`** — the Adaptive→Proficient argument, mapped to evidence.
4. **`evidence-gaps.md`** — an honest list of what this pack does *not* prove, and why.

Then open the numbered evidence folders as the narrative references them.

## What is real vs. generated-for-this-pack

This pack is built from a **real, 30-commit, 8-release engineering project** (June–August
2026). Nothing historical was invented. Two categories of artifact exist:

| Marker | Meaning |
|---|---|
| *(from the repository)* | Pre-existing project artifacts — source, ADRs, git history, CI, tests. |
| *Generated during evidence preparation* | Real work performed **now** using the existing tool — running the 203-test suite, running the advisor over the bundled fixture, and executing a trust-boundary probe through the real production merge code. Every such artifact is labelled and reproducible via `reproducibility/`. |

No AI chat transcripts are included, because none were preserved from the original build —
see `evidence-gaps.md`. Rather than reconstruct fake conversations, this pack proves the
*engineering residue* of AI collaboration: the trust boundary, the ADRs, the review-driven
iteration history, and a live demonstration that the AI layer cannot override deterministic truth.

## Layout

```
evidence-pack/
├── README.md                     ← you are here
├── assessment-narrative.md       ← evaluator narrative (start here)
├── level-4-readiness.md          ← Adaptive → Proficient argument
├── evidence-matrix.md            ← criterion → artifact map
├── evidence-gaps.md              ← honest limitations
├── reproducibility/              ← re-run every generated artifact yourself
│
├── 01-interaction/               ← structured AI collaboration (prompt contract, iteration)
├── 02-evaluation/                ← AI output validated: trust-boundary probe + scenarios
├── 03-refinement/                ← meaningful improvement over generations (git + diffs)
├── 04-operationalization/        ← AI embedded in a repeatable workflow (CI, tests, service)
├── 05-judgment/                  ← intentional tradeoffs & governance (decision log)
│
├── architecture/                 ← system diagram, AI vs deterministic boundary marked
└── supporting-evidence/          ← ADRs + key source excerpts referenced above
```
